package day0430;
// 처음 세팅법 설정 키맵 에서 windows -> eclipse 로 변환
// 플러그인 마켓플레이스 에서 한국어 랑 레인보우브라켓? 깔기

public class Ex01 {
    public static void main(String[] args) {
        System.out.print("Hello, WORLD!!!");
    }
}
