package day0430;
// 기본형 데이터타입 02. 실수형 데이터타입
// 실수란?
// 소수점이 존재하는 숫자
// float: 32비트의 실수체계
// double: 64비트의 실수체계

public class Ex08RelNumber {
}
