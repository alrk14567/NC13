package studyEx1;

public class Number {
    public static void main(String[] args) {
        System.out.println(6 + 2);
        System.out.println(6 - 2);
        System.out.println(6 * 2);
        System.out.println(6 / 2);

        System.out.println(Math.PI);                // 수학과 관련된 캐비넷
        System.out.println(Math.floor(Math.PI));
        System.out.println(Math.ceil(Math.PI));
    }
}
