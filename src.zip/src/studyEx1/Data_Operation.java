package studyEx1;

public class Data_Operation {
    public static void main(String[] args) {
        System.out.println(6);
        System.out.println("six");

        System.out.println("6");

        System.out.println(6+6);
        System.out.println("6"+"6");

        System.out.println(6*6);
//        System.out.prinln("6"*"6");

        System.out.println("1111".length());        //문자열의 길이
//        System.out.println(1111.length());
        String i = "Hello World";
        System.out.println(i);
        System.out.println('h');
        System.out.println("H");



    }
}
