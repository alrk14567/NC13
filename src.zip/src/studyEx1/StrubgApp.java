package studyEx1;

public class StrubgApp {
    public static void main(String[] args) {

        System.out.println('h');  // '' char  로 표현하고 "" 이거는 string 이다?? 한글자일때

        System.out.println("Hello"
        + "World");
        System.out.println("Hello \nWorld");
        System.out.println("Hello \"World\"");

        System.out.println("Hello World".length());
        System.out.println("Hello. [[[name]]] ... bye".replace("[[[name]]]","duru"));





    }
}
