package studyEx1;

public class Debuggingl {
    public static void main (String[] args) {

    }
}
