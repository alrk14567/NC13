package studyEx1;

import java.sql.SQLOutput;
import java.util.Scanner;
public class Ex02scanner {
    public static void main(String[] args){
        Scanner sc =new Scanner(System.in);

        int i = sc.nextInt();
        System.out.println(i);

    }
}
