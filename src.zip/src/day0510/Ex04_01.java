package day0510;

public class Ex04_01 {
}
